<pre class="layui-code" lay-options="{preview: true, text: {preview: '综合用法'}, layout: ['preview', 'code'], tools: ['full']}">
  <textarea>
AAA

<!-- import layui -->
<script>
layui.use(function(){
  var MOD_NAME = layui.MOD_NAME;

  
});
</script>
  </textarea>
</pre>

<h3 id="demo-NAME" class="ws-anchor ws-bold">示例标题</h3>

<pre class="layui-code" lay-options="{preview: true, layout: ['preview', 'code'], tools: ['full']}">
  <textarea>
AAA

<!-- import layui -->
<script>
layui.use(function(){
  var MOD_NAME = layui.MOD_NAME;

  
});
</script>
  </textarea>
</pre>